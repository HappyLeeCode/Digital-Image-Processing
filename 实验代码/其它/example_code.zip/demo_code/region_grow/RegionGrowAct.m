clc;
clear;
close all;
img = imread('../../standard_test_images/house.tif');
I = im2gray(img); 
if( exist('x','var') == 0 && exist('y','var') == 0)
    figure;
    subplot(231),imshow(I);title('原图');
    I = double(I);
    [y,x] = getpts;%鼠标取点  回车确定
    x1 = round(x(1));%选择种子点
    y1 = round(y(1));
end
% 质心生长法
J1 = CentroidGrowthMethod(I, [x1, y1], 15);
% 简单生长法
J2 = SimpleRegionGrow(I, [x1, y1], 15);
% 混合生长法
J3=regionGrow(I,[x1,y1],10);
subplot(232),imshow(img),title('标记位置');
hold on 
plot(y, x, 'p')
hold off;
subplot(233),imagesc(J1),title('质心生长法');
subplot(234),imagesc(J2),title('简单生长法');
subplot(235),imagesc(J3),title('混合生长法');

