function [G] = IsotropicSobel(F)
%各向同性Sobel算子
% 输入：灰度图像
% 输出：分割后的图像
f=double(F);
[m,n]=size(f);
g=zeros(m,n);
for i=2:m-1
    for j=2:n-1
        DX=(f(i+1,j-1)-f(i-1,j-1))+2^0.5*(f(i+1,j)-f(i-1,j))+(f(i+1,j+1)-f(i-1,j+1));
        DY=(f(i-1,j+1)-f(i-1,j-1))+2^0.5*(f(i,j+1)-f(i,j-1))+(f(i+1,j+1)-f(i+1,j-1));
        g(i,j)=round(sqrt(DX*DX+DY*DY)*4/(2+2^0.5));
    end
end
G=uint8(g);
end
