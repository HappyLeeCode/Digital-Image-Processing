function [ G ] = Sobel( F )
%Sobel算子
% 输入：灰度图像
% 输出：分割后的图像
if size(F,3)>1
    F = rgb2gray(F);
end
F = im2double(F); 
mBlock = fspecial('sobel');
mImgDy = imfilter(F, mBlock, 'replicate');
mImgDx = imfilter(F, mBlock','replicate');
G = sqrt(mImgDy.*mImgDy+mImgDx.*mImgDx);
end


