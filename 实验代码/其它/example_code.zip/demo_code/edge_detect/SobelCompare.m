F = imread('../standard_test_images/cameraman.tif');
F = im2gray(F);
G1 =IsotropicSobel(F);
G3 =Sobel(F);
G2=edge(F,'sobel');

f=double(F);
[m,n]=size(f);
g=zeros(m,n);
for i=2:m-1
    for j=2:n-1
        DX=(f(i+1,j-1)-f(i-1,j-1))+2*(f(i+1,j)-f(i-1,j))+(f(i+1,j+1)-f(i-1,j+1));
        DY=(f(i-1,j+1)-f(i-1,j-1))+2*(f(i,j+1)-f(i,j-1))+(f(i+1,j+1)-f(i+1,j-1));
        g(i,j)=round(sqrt(DX*DX+DY*DY));
    end
end
G4=uint8(g);
figure;
subplot(2,3,1), imshow(F), title('原图像');
subplot(2,3,2), imshow(G3), title('使用内置函数自定义Sobel');
subplot(2,3,3), imshow(G1), title('IsoSobel');
subplot(2,3,4), imshow(G2), title('内置Sobel');
subplot(2,3,5), imshow(G4), title('完全自定义Sobel');
