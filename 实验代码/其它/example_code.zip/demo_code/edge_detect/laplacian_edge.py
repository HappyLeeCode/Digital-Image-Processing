import cv2
import numpy as np

# 读取图像
image = cv2.imread('../standard_test_images/cameraman.tif', cv2.IMREAD_GRAYSCALE)

# Laplacian 算子
laplacian_kernel = np.array([[0, 1, 0],
                             [1, -4, 1],
                             [0, 1, 0]])

# 应用高斯滤波器进行平滑处理
image = cv2.GaussianBlur(image, (5, 5), 0.01)

# 应用laplacian滤波器进行锐化处理
laplacian_output = cv2.filter2D(image.astype(np.float32), -1, laplacian_kernel)
# laplacian_output = cv2.Laplacian(image, cv2.CV_64F)

# 获得梯度幅值图像
laplacian_output_mag = np.uint8(np.absolute(laplacian_output))
laplacian_output_mag = ((laplacian_output_mag - np.min(laplacian_output_mag)) /
                        (np.max(laplacian_output_mag) - np.min(laplacian_output_mag)))
# 过零检测
threshold = 10  # 过零检测的阈值
edges = np.zeros_like(laplacian_output)
rows, cols = edges.shape
for i in range(1, rows - 1):
    for j in range(1, cols - 1):
        patch = laplacian_output[i-1:i+2, j-1:j+2]
        if np.min(patch) < -threshold and np.max(patch) > threshold:
            edges[i, j] = 255

# 显示结果
cv2.imshow('Original Image', image)
cv2.imshow('Laplacian Sharpened Image', laplacian_output_mag)
cv2.imshow('Edges Detected', edges)
cv2.waitKey(0)
cv2.destroyAllWindows()