
I1 = imread('../standard_test_images/cameraman.tif');
I1 =im2gray(I1);
% Roberts算子边缘检测
BW1=edge(I1,'roberts');
% Prewitt算子边缘检测
BW2=edge(I1,'prewitt');
% Sobel算子边缘检测
BW3=edge(I1,'sobel');
BW4=IsotropicSobel(I1);
BW5=Sobel(I1);
figure('name','4.1.05');
subplot(231),imshow(I1),title('原图');
subplot(232),imshow(BW1,[]),title('roberts');
subplot(233),imshow(BW2,[]),title('prewitt');
subplot(234),imshow(BW3,[]),title('sobel');
subplot(235),imshow(BW4),title('IsotropicSobel');
subplot(236),imshow(BW5),title('自定义Sobel');

I2 = imread('../standard_test_images/cameraman.tif');
% Roberts算子边缘检测
BW1=edge(I2,'roberts');
% Prewitt算子边缘检测
BW2=edge(I2,'prewitt');
% Sobel算子边缘检测
BW3=edge(I2,'sobel');
BW4 = IsotropicSobel(I2);
BW5 = Sobel(I2);

figure('name','5.3.01');
subplot(231),imshow(I2),title('原图');
subplot(232),imshow(BW1,[]),title('roberts');
subplot(233),imshow(BW2,[]),title('prewitt');
subplot(234),imshow(BW3,[]),title('sobel');
subplot(235),imshow(BW4),title('IsotropicSobel');
subplot(236),imshow(BW5),title('自定义Sobel');

I3 = imread('../standard_test_images/cameraman.tif');
I3 =im2gray(I3);
% Roberts算子边缘检测
BW1=edge(I3,'roberts');
% Prewitt算子边缘检测
BW2=edge(I3,'prewitt');
% Sobel算子边缘检测
BW3=edge(I3,'sobel');
BW4=IsotropicSobel(I3);
BW5=Sobel(I3);

figure('name','4.2.07');
subplot(231),imshow(I3),title('原图');
subplot(232),imshow(BW1,[]),title('roberts');
subplot(233),imshow(BW2,[]),title('prewitt');
subplot(234),imshow(BW3,[]),title('sobel');
subplot(235),imshow(BW4),title('IsotropicSobel');
subplot(236),imshow(BW5),title('自定义Sobel');

